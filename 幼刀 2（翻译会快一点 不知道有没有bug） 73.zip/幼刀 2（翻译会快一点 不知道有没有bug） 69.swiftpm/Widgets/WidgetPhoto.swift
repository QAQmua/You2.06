// 📄 完整替换文件：Widgets/WidgetPhoto.swift
import SwiftUI
import PhotosUI

final class PhotoWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerPhotoWidget()
    }
}

class PhotoWidgetManager: ObservableObject {
    static let shared = PhotoWidgetManager()
    
    private let photoIdKey = "App_Widget_4x2_ImageID"
    private let addedKey = "App_Widget_4x2_IsAdded"
    private let pageKey = "App_Widget_4x2_PagePosition"
    private let rowKey = "App_Widget_4x2_RowPosition"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.integer(forKey: rowKey)
        self.widgetRow = min(max(0, rawRow), 4)
    }
}

struct PhotoWidget4x2View: View {
    @ObservedObject var manager = PhotoWidgetManager.shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        let s = uiScale
        
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Group {
                    if let data = manager.widgetImageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: geo.size.width, height: geo.size.height)
                            .clipped()
                    } else {
                        ZStack {
                            LinearGradient(
                                colors: [Color.purple.opacity(0.35), Color.blue.opacity(0.25)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            VStack(spacing: 8 * s) {
                                Image(systemName: "photo.on.rectangle.angled")
                                    .font(.system(size: 32 * s))
                                    .foregroundColor(.white.opacity(0.9))
                                Text(translator.translate("卡片"))
                                    .font(.system(size: 15 * s))
                                    .fontWeight(appearance.systemFontWeight)
                                    .foregroundColor(.white)
                                Text(translator.translate("点击选取相册照片"))
                                    .font(.system(size: 11 * s))
                                    .fontWeight(appearance.systemFontWeight)
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        .frame(width: geo.size.width, height: geo.size.height)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                        .stroke(Color.white.opacity(0.18), lineWidth: 1 * s)
                )
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        }
        .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
    }
}

// 🌟 卡片小组件专属定制弹窗（支持更换照片与清除恢复默认）
struct EditPhotoWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var manager = PhotoWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 20) {
                PhotoWidget4x2View()
                    .frame(height: 160 * s)
                    .padding(.horizontal, 16)
                    .padding(.top, 20)
                
                List {
                    Section {
                        PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                            HStack {
                                Label("更换照片".tr, systemImage: "photo.badge.plus")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                            }
                        }
                        .foregroundColor(.primary)
                        
                        if manager.widgetImageData != nil {
                            Button(role: .destructive, action: {
                                withAnimation { manager.widgetImageData = nil }
                            }) {
                                Label("恢复默认卡片".tr, systemImage: "trash")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("卡片照片".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .task(id: selectedPhotoItem) {
                if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { manager.widgetImageData = data }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
        }
        .presentationDetents([.medium])
    }
}

extension WidgetRegistry {
    func registerPhotoWidget() {
        let s = uiScale
        registerWidget(
            id: "photo",
            title: "widget_photo_title",
            subtitle: "sub_photo",
            badge: "4×2",
            manager: PhotoWidgetManager.shared,
            desktopView: {
                PhotoWidget4x2View()
            },
            previewView: {
                PhotoWidget4x2View()
                    .frame(height: 160 * s)
                    .padding(.horizontal, 16 * s)
            },
            editSheetView: { show in
                EditPhotoWidgetSheet(isPresented: show)
            }
        )
    }
}
