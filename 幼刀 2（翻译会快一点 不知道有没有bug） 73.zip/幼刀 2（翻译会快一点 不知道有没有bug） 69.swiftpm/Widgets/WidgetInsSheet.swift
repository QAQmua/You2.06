// 📄 完整替换文件：Widgets/WidgetInsSheet.swift
import SwiftUI
import PhotosUI

struct EditInsWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = InsPostWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @State private var selectedAvatarItem: PhotosPickerItem? = nil
    @State private var selectedPostItem: PhotosPickerItem? = nil
    @ObservedObject var appearance = SystemAppearance.shared
    
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let bgPresets = ["#FFFFFF", "#EDEDF2", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#E5E5EA"]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 🌟 方案 3：纯净自然留白（无分割线、无渐变，纯靠舒适呼吸间距）
                if widgetManager.isPinPreviewToTop {
                    previewCardView
                        .background(Color(UIColor.systemGroupedBackground))
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !widgetManager.isPinPreviewToTop {
                            previewCardView
                        }
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("背景与显示".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.isPinPreviewToTop) {
                                Label("固定顶部预览".tr, systemImage: "pin.fill").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            Divider()
                            Toggle(isOn: $widgetManager.isTransparentBackground) {
                                Label("背景透明".tr, systemImage: "circle.lefthalf.filled").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if !widgetManager.isTransparentBackground {
                                Divider()
                                WidgetColorPaletteRow(title: "背景底色".tr, selectedHex: widgetManager.backgroundColorHex, presets: bgPresets, currentColor: widgetManager.backgroundColor, onSelectHex: { widgetManager.backgroundColorHex = $0 }, onPickColor: { widgetManager.backgroundColorHex = $0.toHex() })
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("外边框描边".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.hasBorder) {
                                Label("启用外边框描边".tr, systemImage: "square.dashed").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if widgetManager.hasBorder {
                                Divider()
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack {
                                        Text("描边粗细".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                        Spacer()
                                        Text(String(format: "%.1f pt", widgetManager.borderWidth)).font(.caption).foregroundColor(.secondary)
                                    }
                                    Slider(value: $widgetManager.borderWidth, in: 0.1...6.0, step: 0.1)
                                }
                                Divider()
                                WidgetColorPaletteRow(title: "描边颜色".tr, selectedHex: widgetManager.borderColorHex, presets: borderPresets, currentColor: widgetManager.borderColor, onSelectHex: { widgetManager.borderColorHex = $0 }, onPickColor: { widgetManager.borderColorHex = $0.toHex() })
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("照片".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            PhotosPicker(selection: $selectedAvatarItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换头像".tr, systemImage: "person.crop.circle.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            if widgetManager.avatarImageData != nil {
                                Divider()
                                Button(role: .destructive, action: { withAnimation { widgetManager.avatarImageData = nil } }) {
                                    Label("清空已选头像".tr, systemImage: "trash").font(.system(size: 15, weight: appearance.systemFontWeight))
                                }
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("头像大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.avatarSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.avatarSize, in: 28...60, step: 1)
                            }
                            Divider()
                            PhotosPicker(selection: $selectedPostItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换发帖主图".tr, systemImage: "photo.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            if widgetManager.postImageData != nil {
                                Divider()
                                Button(role: .destructive, action: { withAnimation { widgetManager.postImageData = nil } }) {
                                    Label("清空已选发帖图".tr, systemImage: "trash").font(.system(size: 15, weight: appearance.systemFontWeight))
                                }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "左上角文字".tr, placeholder: "如：取消".tr, text: $widgetManager.headerCancelText, size: $widgetManager.headerCancelSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerCancelWeightName, selectedHex: widgetManager.headerCancelColorHex, currentColor: widgetManager.headerCancelColor, onSelectHex: { widgetManager.headerCancelColorHex = $0 }, onPickColor: { widgetManager.headerCancelColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "顶部主标题".tr, placeholder: "如：发布动态".tr, text: $widgetManager.headerTitle, size: $widgetManager.headerTitleSize, minSize: 11, maxSize: 22, selectedWeightName: $widgetManager.headerTitleWeightName, selectedHex: widgetManager.headerTitleColorHex, currentColor: widgetManager.headerTitleColor, onSelectHex: { widgetManager.headerTitleColorHex = $0 }, onPickColor: { widgetManager.headerTitleColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "右上角文字".tr, placeholder: "如：send".tr, text: $widgetManager.headerSendText, size: $widgetManager.headerSendSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerSendWeightName, selectedHex: widgetManager.headerSendColorHex, currentColor: widgetManager.headerSendColor, onSelectHex: { widgetManager.headerSendColorHex = $0 }, onPickColor: { widgetManager.headerSendColorHex = $0.toHex() })
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("右上角图标设置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("图标大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.1f pt", widgetManager.sendIconSize)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconSize, in: 8.0...35.0, step: 0.5)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("左右横向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetX)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconOffsetX, in: -30.0...30.0, step: 0.5)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("上下纵向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetY)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconOffsetY, in: -30.0...30.0, step: 0.5)
                            }
                            Divider()
                            WidgetColorPaletteRow(title: "图标颜色".tr, selectedHex: widgetManager.sendIconColorHex, presets: textColors, currentColor: widgetManager.sendIconColor, onSelectHex: { widgetManager.sendIconColorHex = $0 }, onPickColor: { widgetManager.sendIconColorHex = $0.toHex() })
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "昵称".tr, placeholder: "如：用户1011".tr, text: $widgetManager.authorName, size: $widgetManager.authorNameSize, minSize: 11, maxSize: 24, selectedWeightName: $widgetManager.authorNameWeightName, selectedHex: widgetManager.authorNameColorHex, currentColor: widgetManager.authorNameColor, onSelectHex: { widgetManager.authorNameColorHex = $0 }, onPickColor: { widgetManager.authorNameColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "个性签名 / ID ".tr, placeholder: "如：User".tr, text: $widgetManager.authorSubText, size: $widgetManager.authorSubTextSize, minSize: 8, maxSize: 18, selectedWeightName: $widgetManager.authorSubTextWeightName, selectedHex: widgetManager.authorSubTextColorHex, currentColor: widgetManager.authorSubTextColor, onSelectHex: { widgetManager.authorSubTextColorHex = $0 }, onPickColor: { widgetManager.authorSubTextColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "发帖正文".tr, placeholder: "如：此刻在想什么...".tr, text: $widgetManager.contentText, size: $widgetManager.contentTextSize, minSize: 10, maxSize: 22, selectedWeightName: $widgetManager.contentTextWeightName, selectedHex: widgetManager.contentTextColorHex, currentColor: widgetManager.contentTextColor, onSelectHex: { widgetManager.contentTextColorHex = $0 }, onPickColor: { widgetManager.contentTextColorHex = $0.toHex() })
                    }
                    .padding(.bottom, 32)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("ins 发布页".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .task(id: selectedAvatarItem) {
                if let data = try? await selectedAvatarItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { widgetManager.avatarImageData = data }
                }
            }
            .task(id: selectedPostItem) {
                if let data = try? await selectedPostItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { widgetManager.postImageData = data }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    private var previewCardView: some View {
        let s = uiScale
        return InsPostWidget4x4View(
            manager: widgetManager,
            showDashedBorder: true,
            onDeletePostImage: { withAnimation { widgetManager.postImageData = nil } }
        )
        .frame(height: 330 * s)
        .shadow(color: Color.black.opacity(0.06), radius: 8, y: 4)
        .padding(.horizontal, 16 * s)
        .padding(.top, 14 * s)
        .padding(.bottom, 16 * s) // 🌟 纯净呼吸留白
    }
}
