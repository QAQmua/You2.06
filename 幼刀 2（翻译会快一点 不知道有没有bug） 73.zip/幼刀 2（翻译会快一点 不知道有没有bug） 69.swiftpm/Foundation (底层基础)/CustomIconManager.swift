import SwiftUI

// 📄 App 实体模型
struct AppItem: Identifiable, Codable, Equatable {
    let id: String
    var title: String
    var icon: String
    var colorName: String
    
    var color: Color {
        switch colorName {
        case "gray": return .gray
        case "green": return .green
        case "blue": return .blue
        case "orange": return .orange
        case "red": return .red
        case "purple": return .purple
        default: return .gray
        }
    }
    
    func localizedTitle(customManager: CustomIconManager, lang: LanguageManager) -> String {
        if let custom = customManager.getTitle(for: self.id), !custom.isEmpty {
            return AutoTranslationManager.shared.translate(custom, to: lang.currentLanguage)
        }
        let directKeyMatch = lang.tr(self.title)
        if directKeyMatch != self.title { return directKeyMatch }
        let appKeyMatch = lang.tr("app_\(self.id)")
        if appKeyMatch != "app_\(self.id)" { return appKeyMatch }
        return AutoTranslationManager.shared.translate(self.title, to: lang.currentLanguage)
    }
}

// 📄 拖拽位置枚举
enum AppLocation: Equatable {
    case grid(Int)
    case dock(Int)
    
    var isDock: Bool {
        if case .dock = self { return true }
        return false
    }
}

// 📄 设置应用路由
enum SettingsRoute: Hashable {
    case language
    case appearance
    case wallpaper
    case apiConfig
}

class SettingsNavManager: ObservableObject {
    static let shared = SettingsNavManager()
    @Published var path: [SettingsRoute] = []
    @Published var isInteractingWithSlider: Bool = false
}

// 📄 自定义 App 图标与名称管理器
class CustomIconManager: ObservableObject {
    static let shared = CustomIconManager()
    
    private let titleStorageKey = "App_Custom_App_Titles_Map"
    private let iconIdStorageKey = "App_Custom_App_IconIDs_Map"
    
    @Published var customIcons: [String: Data] = [:]
    
    @Published var customIconIDs: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customIconIDs) {
                    UserDefaults.standard.set(data, forKey: self.iconIdStorageKey)
                }
            }
        }
    }
    
    @Published var customTitles: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customTitles) {
                    UserDefaults.standard.set(data, forKey: self.titleStorageKey)
                }
            }
        }
    }
    
    init() {
        if let data = UserDefaults.standard.data(forKey: titleStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customTitles = decoded
            for title in self.customTitles.values {
                AutoTranslationManager.shared.prewarm(text: title)
            }
        }
        
        if let data = UserDefaults.standard.data(forKey: iconIdStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customIconIDs = decoded
            for (appId, imageId) in decoded {
                if let imageData = LocalImageStore.shared.load(id: imageId) {
                    self.customIcons[appId] = imageData
                    _ = ImageBitmapCache.shared.image(from: imageData)
                }
            }
        }
    }
    
    func setIcon(for appId: String, imageData: Data) {
        customIcons[appId] = imageData
        _ = ImageBitmapCache.shared.image(from: imageData)
        
        let oldId = customIconIDs[appId]
        LocalImageStore.shared.replace(oldId: oldId, with: imageData) { newId in
            if let newId = newId {
                self.customIconIDs[appId] = newId
            }
        }
    }
    
    func removeIcon(for appId: String) {
        if let oldData = customIcons[appId] {
            ImageBitmapCache.shared.remove(for: oldData)
        }
        customIcons.removeValue(forKey: appId)
        if let oldId = customIconIDs[appId] {
            LocalImageStore.shared.delete(id: oldId)
            customIconIDs.removeValue(forKey: appId)
        }
    }
    
    func getIcon(for appId: String) -> Data? {
        return customIcons[appId]
    }
    
    func setTitle(for appId: String, title: String) {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            customTitles.removeValue(forKey: appId)
        } else {
            customTitles[appId] = trimmed
            Task {
                for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                    _ = await AutoTranslationManager.shared.translateAsync(trimmed, to: lang)
                }
            }
        }
    }
    
    func removeTitle(for appId: String) {
        customTitles.removeValue(forKey: appId)
    }
    
    func getTitle(for appId: String) -> String? {
        return customTitles[appId]
    }
}
